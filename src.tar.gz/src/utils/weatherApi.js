export const getWeather = ({ latitude, longitude }, APIkey) => {
  return fetch(
    `https://api.openweathermap.org/data/2.5/weather?lat=${latitude}&lon=${longitude}&units=imperial&appid=${APIkey}`,
  )
    .then((res) => {
      if (res.ok) return res.json();
      return Promise.reject(`Error: ${res.status}`);
    })
    .then((data) => {
      return {
        city: data.name,
        temperature: {
          F: Math.round(data.main.temp),
        },
        icon: data.weather[0].icon,
      };
    });
};
