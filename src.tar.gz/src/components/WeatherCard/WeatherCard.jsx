import "./WeatherCard.css";
import { weatherConditions } from "../../utils/weatheroptions";

export default function WeatherCard({ weatherData }) {
  const weatherOption = weatherOptions.filter((option) => {
    return (
      option.day === weatherData.isDay &&
      option.condition === weatherData.condition
    );
  });

  return (
    <section className="weather-card">
      <p className="weather-card__temp">{weatherData.temperature.F}°F</p>
      <img
        className="weather-card__icon"
        src={`https://openweathermap.org/img/wn/${weatherData.icon}@2x.png`}
        alt="Weather icon"
      />
    </section>
  );
}
